// wwwroot/config.js
window.__CONFIG__ = {
  API_URL: "http://localhost:5004/swdjk",
};
